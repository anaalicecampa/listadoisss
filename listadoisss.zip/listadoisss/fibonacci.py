numero = int(input("Digite um número inteiro: "))

fibonacci = [0, 1]

for i in range(2, numero):
    proximo = fibonacci[i - 1] + fibonacci[i - 2]
    fibonacci.append(proximo)

print("Sequência de Fibonacci até o", numero, "º termo:")
for num in fibonacci[:numero]:
    print(num, end=" ")