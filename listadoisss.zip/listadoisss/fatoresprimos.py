numero = int(input("Digite um número inteiro: "))

print("Fatores primos de", numero, ":")

fator = 2
while fator <= numero:
    if numero % fator == 0:
        print(fator)
        numero /= fator
    else:
        fator += 1