numero = int(input("Digite um número inteiro: "))

while True:
    limite = int(input("Digite o limite da tabuada (0 para sair): "))
    if limite == 0:
        break
    print("Tabuada de", numero, "até", limite, ":")
    for i in range(1, limite+1):
        print(numero, "x", i, "=", numero*i)
