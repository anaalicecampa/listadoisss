numero = int(input("Digite um número inteiro: "))

print("Números perfeitos menores ou iguais a", numero, ":")

for i in range(1, numero+1):
    soma_divisores = sum([divisor for divisor in range(1, i) if i % divisor == 0])
    if soma_divisores == i:
        print(i)