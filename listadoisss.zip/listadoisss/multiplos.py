numero = int(input("Digite um número inteiro: "))

for i in range(1, 100):
    if numero * i < 100:
        print(numero * i)
    else:
        break
